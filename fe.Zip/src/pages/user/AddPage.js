import React from 'react'
import UserAddComponent from '../../components/user/UserAddComponent'

const AddPage = () => {
    return (
        <div>
            <UserAddComponent />
        </div>
    )
}

export default AddPage