import React from 'react'
import UserModifyComponent from '../../components/user/UserModifyComponent'

const ModifyPage = () => {
    return (
        <div>
            <UserModifyComponent />
        </div>
    )
}

export default ModifyPage