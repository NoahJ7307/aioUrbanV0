import React from 'react'
import UserAccessListComponent from '../../components/user/UserApprovalComponent'

const ApprovalPage = () => {
    return (
        <div>
            <UserAccessListComponent />
        </div>
    )
}

export default ApprovalPage