import React from 'react'
import UserListComponent from '../../components/user/UserListComponent'

const ListPage = () => {
    return (
        <div>
            <UserListComponent />
        </div>
    )
}

export default ListPage