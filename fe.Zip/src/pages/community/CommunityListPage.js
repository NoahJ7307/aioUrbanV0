import React from 'react'
import CommunityListComponent from '../../components/community/CommunityListComponent'



const CommunityListPage = () => {
    console.log('communit list ')
    return (
        <div>
            <CommunityListComponent />
        </div>
    )
}

export default CommunityListPage