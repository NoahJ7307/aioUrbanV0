import React from 'react'

const MainComponent = () => {
  return (
    <div>MainComponent</div>
  )
}

export default MainComponent