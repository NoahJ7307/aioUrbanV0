import React from 'react'
import useCustomLogin from '../hook/useCustomLogin'

const MainComponent = () => {
  return (
    <div>MainComponent</div>
  )
}

export default MainComponent