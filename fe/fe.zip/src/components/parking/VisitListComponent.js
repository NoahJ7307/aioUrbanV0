import React from 'react'

const VisitListComponent = () => {
  return (
    <div>VisitListComponent</div>
  )
}

export default VisitListComponent