import React from 'react'

const EntryListComponent = () => {
  return (
    <div>EntryListComponent</div>
  )
}

export default EntryListComponent