import React, { useCallback, useEffect, useState } from 'react'
import { getList, getUserList } from '../api/parking/regularApi'
import useCustom from '../hook/useCustom'
import { useNavigate, useOutletContext } from 'react-router-dom'
import PageComponent from '../common/PageComponent'
import useCustomLogin from '../hook/useCustomLogin'
import { deleteChecked } from '../api/userApi'

const initState = {
    dtoList: [],
    pageNumList: [],
    pageRequestDTO: null,
    prev: false,
    next: false,
    totalCount: 0,
    prevPage: 0,
    nextPage: 0,
    totalPage: 0,
    current: 0
}

const RegularListComponent = () => {

    const navigate = useNavigate()
    const [serverData, setServerData] = useState(initState)
    const { page, size, moveToList } = useCustom()
    const [checked, setChecked] = useState([])
    const { exceptionHandler, loadLoginData } = useCustomLogin()

    useEffect(() => {
        if (loadLoginData().role !== 'ADMIN' && loadLoginData().role !== 'ROOT') {
            alert('권한이 없습니다')
            navigate({ pathname: '/login' })
        }
    }, [loadLoginData, navigate])

    const handleClickModify = useCallback(() => {
        if (checked.length == 1) {
            navigate({ pathname: `modify/${checked[0]}` })  // 1개 체크 시
        } else if (checked.length > 1) {
            alert("하나만 선택해주세요") // 여러개 체크 시
        } else {
            alert("선택된 항목이 없습니다") // 미체크 시
        }
    }, [checked, navigate])
    const handleClickDelete = async () => {
        if (checked.length > 0) {
            await deleteChecked(checked)
            navigate({ pathname: '/regular/list' }) // 삭제 후 새로고침 기능 수행
        } else {
            alert("선택된 항목이 없습니다")
            navigate({ pathname: '/regular/list' })
        }
    }

    const handleCheckChange = (uno) => {
        setChecked(checkedItem => {
            if (checkedItem.includes(uno)) {
                return checkedItem.filter(item => item !== uno)
            } else {
                return [...checkedItem, uno];
            }
        })
    }

    // 체크된 항목이 변경 시 부모에 [uno] 전달 / 부모(UserPage) 업데이트
    useEffect(() => {
        if (checked.length > 0) {
            setChecked(checked);
            console.log("checked:" + checked)
        } else {
            setChecked([]);
        }
    }, [checked, setChecked]);

    useEffect(() => {
        if (loadLoginData().role !== 'ADMIN' && loadLoginData().role !== 'ROOT') {
            alert('권한이 없습니다')
            navigate({ pathname: '/login' })
        }
    }, [loadLoginData, navigate])

    useEffect(() => {
        if (loadLoginData().role == 'ADMIN' || loadLoginData().role == 'ROOT') {
            getList({ page, size }).then(data => {
                if (data.error) {
                    exceptionHandler(data)
                } else {
                    setServerData(data);
                }
            })
        } else {
            getUserList({ page, size }).then(data => {
                if (data.error) {
                    exceptionHandler(data)
                } else {
                    setServerData(data);
                }
            })
        }
    }, [page, size])

    return (
        <div>

            <ul className='flex justify-center'>
                <li>
                    <button className='bg-gray-300 p-2 mr' onClick={() => handleClickModify}>
                        Modify
                    </button>
                </li>
                <li>
                    <button className='bg-gray-300 p-2 mr' onClick={() => handleClickDelete}>
                        Delete
                    </button>
                </li>
            </ul>
            <div className="grid grid-cols-6">
                <div>No</div>
                <div>CarNumber</div>
                <div>name</div>
                <div>phoneNumber</div>
                <div>regDate</div>
            </div>

            {/* 유저 데이터를 map으로 렌더링 */}
            {serverData.dtoList.map((user, index) => (
                <div key={index} className="grid grid-cols-6">
                    <div>
                        <input
                            type='checkbox'
                            checked={checked.includes(user.rpno)} // 페이지 이동 시 체크항목 유지
                            onChange={() => handleCheckChange(user.uno)}
                        />
                    </div>
                    <div>{user.CarNum}</div>
                    <div>{user.name}</div>
                    <div>{user.phone}</div>
                    <div>{user.regDate}</div>
                </div>
            ))}
            <PageComponent serverData={serverData} movePage={moveToList} />
        </div>
    );
}

export default RegularListComponent