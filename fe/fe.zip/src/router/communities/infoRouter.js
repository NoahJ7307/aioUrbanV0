import InfoPage from '../../pages/community/info/InfoPage';



const infoRouter = [
    {
        path: "info",
        element: <InfoPage />,
        children: [

        ]
    },
];


export default infoRouter