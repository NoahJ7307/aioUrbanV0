import React from 'react'
import RegularModifyComponent from '../../components/parking/RegularModifyComponent'

const RegularModifyPage = () => {
    return (
        <RegularModifyComponent />
    )
}

export default RegularModifyPage