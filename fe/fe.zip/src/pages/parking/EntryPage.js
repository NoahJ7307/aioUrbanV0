import React from 'react'
import EntryListComponent from '../../components/parking/EntryListComponent'

const EntryPage = () => {
  return (
    <EntryListComponent />
  )
}

export default EntryPage