import React, { useCallback, useEffect } from 'react'
import { Outlet, useNavigate, useOutletContext } from 'react-router-dom'
import useCustomLogin from '../../components/hook/useCustomLogin'
import RegularListComponent from '../../components/parking/RegularListComponent'
import { deleteChecked } from '../../components/api/userApi'

const RegularPage = () => {

  return (
    <div>
      <RegularListComponent />
      <Outlet />
    </div>
  )
}

export default RegularPage