import React from 'react'
import RegularAddComponent from '../../components/parking/RegularAddComponent'

const RegularAddPage = () => {
    return (
        <RegularAddComponent />
    )
}

export default RegularAddPage