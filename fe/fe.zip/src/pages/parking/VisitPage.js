import React from 'react'
import VisitListComponent from '../../components/parking/VisitListComponent'

const VisitPage = () => {
  return (
    <VisitListComponent />
  )
}

export default VisitPage