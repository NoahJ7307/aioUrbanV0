import React from 'react'

import CommunityModifyComponents from '../../components/community/CommunityModifyComponents'


const CommnunityModifyPage = () => {
    console.log('communit modify ')
    return (
        <div>
            <CommunityModifyComponents />
        </div>
    )
}

export default CommnunityModifyPage