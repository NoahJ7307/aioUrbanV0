import React from 'react'
import CommunityListComponent from '../../components/community/CommunityListComponent'
import CommunityAddComponents from '../../components/community/CommunityAddComponents'



const CommnunityAddPage = () => {
    console.log('communit add ')
    return (
        <div>
            <CommunityAddComponents />
        </div>
    )
}

export default CommnunityAddPage