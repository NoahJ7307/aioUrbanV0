import React from 'react'
import StudyModify from '../../../components/facilities/study/StudyModify'

const StudyModifyPage = () => {
    return (
        <div>
            <StudyModify />
        </div>
    )
}

export default StudyModifyPage