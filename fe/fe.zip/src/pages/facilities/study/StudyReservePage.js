import React from 'react'
import StudyReserve from '../../../components/facilities/study/StudyReserve'

const StudyReservePage = () => {
    return (
        <div>
            <StudyReserve/>
        </div>
    )
}

export default StudyReservePage