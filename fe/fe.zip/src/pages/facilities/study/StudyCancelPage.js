import React from 'react'
import StudyCancel from '../../../components/facilities/study/StudyCancel'

const StudyCancelPage = () => {
    return (
        <div>
            <StudyCancel/>
        </div>
    )
}

export default StudyCancelPage