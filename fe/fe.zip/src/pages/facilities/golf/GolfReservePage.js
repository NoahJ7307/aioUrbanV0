import React from 'react'
import GolfReserve from '../../../components/facilities/golf/GolfReserve'

const GolfReservePage = () => {
  return (
    <div><GolfReserve/></div>
  )
}

export default GolfReservePage