import React from 'react'
import GolfList from '../../../components/facilities/golf/GolfList'

const GolfListPage = () => {
  return (
    <div><GolfList/></div>
  )
}

export default GolfListPage