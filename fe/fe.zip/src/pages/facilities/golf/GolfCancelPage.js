// import React from 'react'
// import GolfCancel from '../../../components/facilities/golf/GolfCancel'

// const GolfCancelPage = () => {
//   return (
//     <div><GolfCancel/></div>
//   )
// }

// export default GolfCancelPage