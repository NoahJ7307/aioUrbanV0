import React from 'react'
import GolfModify from '../../../components/facilities/golf/GolfModify'

const GolfModifyPage = () => {
  return (
    <div><GolfModify/></div>
  )
}

export default GolfModifyPage