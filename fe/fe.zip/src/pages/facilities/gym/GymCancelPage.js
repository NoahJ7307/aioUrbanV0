import React from 'react'
import GymCancel from '../../../components/facilities/gym/GymCancel'

const GymCancelPage = () => {
  return (
    <div><GymCancel/></div>
  )
}

export default GymCancelPage