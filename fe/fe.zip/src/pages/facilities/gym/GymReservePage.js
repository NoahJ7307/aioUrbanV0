import React from 'react'
import GymReserve from '../../../components/facilities/gym/GymReserve'

const GymReservePage = () => {
  return (
    <div><GymReserve/></div>
  )
}

export default GymReservePage