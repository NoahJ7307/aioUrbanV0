import React from 'react'
import GymModify from '../../../components/facilities/gym/GymModify'

const GymModifyPage = () => {
  return (
    <div><GymModify/></div>
  )
}

export default GymModifyPage