import React from 'react'
import GymList from '../../../components/facilities/gym/GymList'

const GymListPage = () => {
    return (
        <div>
            <GymList />
        </div>
    )
}

export default GymListPage