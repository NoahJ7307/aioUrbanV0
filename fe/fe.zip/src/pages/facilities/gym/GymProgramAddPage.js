import React from 'react'
import GymProgramAdd from '../../../components/facilities/gym/GymProgramAdd'

const GymProgramAddPage = () => {
  return (
    <div><GymProgramAdd /></div>
  )
}

export default GymProgramAddPage