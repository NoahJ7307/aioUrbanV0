package com.allinone.proja3.proja3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proja3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
