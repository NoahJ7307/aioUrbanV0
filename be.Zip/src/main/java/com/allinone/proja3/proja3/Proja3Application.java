package com.allinone.proja3.proja3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proja3Application {

	public static void main(String[] args) {
		SpringApplication.run(Proja3Application.class, args);
	}

}
