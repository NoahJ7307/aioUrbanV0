package com.allinone.proja3.proja3.model;

public enum UserRole {
    PENDING, USER, ADMIN, ROOT;
}
