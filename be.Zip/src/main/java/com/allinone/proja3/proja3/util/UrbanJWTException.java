package com.allinone.proja3.proja3.util;

public class UrbanJWTException extends RuntimeException{
    public UrbanJWTException(String message) {
        super(message);
    }
}
